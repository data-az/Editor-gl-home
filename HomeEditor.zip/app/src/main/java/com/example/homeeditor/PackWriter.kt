package com.example.homeeditor

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Превращает экран в .mcpack. Структура та же, что у главного экрана в ванильном паке. */
object PackWriter {

    fun write(out: OutputStream, els: List<El>, bg: ByteArray?) {
        ZipOutputStream(out).use { z ->
            fun put(name: String, data: ByteArray) {
                z.putNextEntry(ZipEntry(name))
                z.write(data)
                z.closeEntry()
            }
            put("manifest.json", manifest().toByteArray(Charsets.UTF_8))
            put("ui/start_screen.json", screen(els).toByteArray(Charsets.UTF_8))
            for (e in els) {
                val png = e.png ?: continue
                if (e.kind == Kind.IMAGE) put("textures/gui/custom/e${e.id}.png", png)
            }
            if (bg != null) {
                for (i in 0..5) put("textures/gui/background/panorama_$i.png", bg)
            }
        }
    }

    private fun manifest(): String = """
{
  "format_version": 2,
  "header": {
    "name": "My Main Menu",
    "description": "Главный экран, сделанный в HomeEditor",
    "uuid": "${UUID.randomUUID()}",
    "version": [1, 0, 0]
  },
  "modules": [
    { "type": "resources", "uuid": "${UUID.randomUUID()}", "version": [1, 0, 0] }
  ]
}
""".trimIndent()

    private fun rgb(c: Int) = JSONArray()
        .put(Color.red(c) / 255.0)
        .put(Color.green(c) / 255.0)
        .put(Color.blue(c) / 255.0)

    private fun screen(els: List<El>): String {
        val root = JSONObject().put("namespace", "start")
        // Та же обёртка, что в ванильном start_screen.json: экран берёт содержимое из start_screen_content
        root.put("start_screen@common.base_screen", JSONObject().put("\$screen_content", "start.start_screen_content"))

        val controls = JSONArray()
        for (e in els) {
            val ref = "e${e.id}"
            val geo = { d: JSONObject ->
                d.put("anchor_from", "top_left").put("anchor_to", "top_left")
                    .put("offset", JSONArray().put(e.x.toInt()).put(e.y.toInt()))
                    .put("size", JSONArray().put(e.w.toInt()).put(e.h.toInt()))
            }
            when (e.kind) {
                Kind.BUTTON -> {
                    val d = JSONObject().put("\$button_text", e.text)
                    geo(d)
                    root.put("$ref@common_buttons.light_text_button", d)
                }
                Kind.LABEL -> {
                    val d = JSONObject().put("type", "label").put("text", e.text).put("color", rgb(e.color))
                    geo(d)
                    root.put(ref, d)
                }
                Kind.IMAGE -> {
                    val d = JSONObject().put("type", "image").put("texture", "textures/gui/custom/$ref")
                    geo(d)
                    root.put(ref, d)
                }
            }
            controls.put(JSONObject().put("@start.$ref", JSONObject()))
        }
        root.put("start_screen_content", JSONObject().put("type", "panel").put("controls", controls))
        return root.toString(2)
    }
}
