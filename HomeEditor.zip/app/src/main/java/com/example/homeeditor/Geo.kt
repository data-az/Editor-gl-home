package com.example.homeeditor

import org.json.JSONArray
import org.json.JSONObject

/** Прямоугольник в условных пикселях интерфейса Minecraft. */
data class R(var x: Float, var y: Float, var w: Float, var h: Float)

fun clampF(v: Float, lo: Float, hi: Float): Float = maxOf(lo, minOf(v, hi))

object Geo {
    /** Размер условного экрана. Реальный экран игры масштабируется от него. */
    const val SW = 960f
    const val SH = 540f

    private val pct = Regex("^(-?[0-9.]+)%")
    private val num = Regex("^(-?[0-9.]+)")

    /** Разбирает значение размера: число, "50%", "100% - 2px" и т.п. */
    fun size(v: Any?, parent: Float): Float {
        val s = v?.toString()?.trim() ?: return parent
        pct.find(s)?.let { return parent * it.groupValues[1].toFloat() / 100f }
        num.find(s)?.let { return it.groupValues[1].toFloat() }
        return parent
    }

    private fun anchor(name: String): Pair<Float, Float> = when (name) {
        "top_middle" -> 0.5f to 0f
        "top_right" -> 1f to 0f
        "left_middle" -> 0f to 0.5f
        "center" -> 0.5f to 0.5f
        "right_middle" -> 1f to 0.5f
        "bottom_left" -> 0f to 1f
        "bottom_middle" -> 0.5f to 1f
        "bottom_right" -> 1f to 1f
        else -> 0f to 0f
    }

    /** Вычисляет положение элемента на экране по его anchor/offset/size. */
    fun resolve(def: JSONObject, parent: R): R {
        val sz: JSONArray? = def.optJSONArray("size")
        val w = if (sz != null) size(sz.opt(0), parent.w) else parent.w
        val h = if (sz != null) size(sz.opt(1), parent.h) else parent.h
        val off: JSONArray? = def.optJSONArray("offset")
        val ox = if (off != null) size(off.opt(0), parent.w) else 0f
        val oy = if (off != null) size(off.opt(1), parent.h) else 0f
        val (fx, fy) = anchor(def.optString("anchor_from", "top_left"))
        val (tx, ty) = anchor(def.optString("anchor_to", "top_left"))
        return R(parent.x + parent.w * tx + ox - w * fx, parent.y + parent.h * ty + oy - h * fy, w, h)
    }
}
