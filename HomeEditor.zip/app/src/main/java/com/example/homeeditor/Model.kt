package com.example.homeeditor

import android.graphics.Bitmap
import android.graphics.Color

enum class Kind { BUTTON, LABEL, IMAGE }

/** Элемент главного экрана. Координаты в условных пикселях 960×540. */
class El(val id: Int, var kind: Kind) {
    var text = ""
    var color = Color.parseColor("#3A7BD5")
    var x = 0f
    var y = 0f
    var w = 200f
    var h = 40f
    var png: ByteArray? = null
    var bitmap: Bitmap? = null
}

/** Весь главный экран: элементы и фон. С него стартует приложение. */
class Model {
    companion object {
        const val SW = 960f
        const val SH = 540f
    }

    val els = mutableListOf<El>()
    var bgPng: ByteArray? = null
    var bgBitmap: Bitmap? = null
    private var nextId = 1

    init {
        // Стартовая раскладка похожа на главное меню Minecraft
        newEl(Kind.LABEL, "MINECRAFT", 280f, 40f, 400f, 70f).color = Color.WHITE
        newEl(Kind.BUTTON, "Играть", 380f, 190f, 200f, 40f)
        newEl(Kind.BUTTON, "Настроить", 380f, 240f, 200f, 40f)
        newEl(Kind.BUTTON, "Магазин", 380f, 290f, 200f, 40f)
        newEl(Kind.BUTTON, "Скины", 380f, 340f, 200f, 40f)
        newEl(Kind.IMAGE, "", 760f, 300f, 120f, 200f)
        newEl(Kind.LABEL, "Версия 1.21", 10f, 508f, 220f, 22f).color = Color.parseColor("#DDDDDD")
    }

    fun newEl(kind: Kind, text: String, x: Float, y: Float, w: Float, h: Float): El {
        val e = El(nextId++, kind)
        e.text = text
        e.x = x; e.y = y; e.w = w; e.h = h
        els.add(e)
        return e
    }

    fun centerX(w: Float) = (SW - w) / 2
    fun centerY(h: Float) = (SH - h) / 2
}
