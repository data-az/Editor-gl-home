package com.example.homeeditor

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object PackExporter {

    /** Пишет ресурс-пак (.mcpack = zip) в out. uiDefs — список UI-файлов из assets. */
    fun export(out: OutputStream, items: List<Element>, bg: Int, uiDefs: String) {
        ZipOutputStream(out).use { z ->
            fun put(name: String, data: ByteArray) {
                z.putNextEntry(ZipEntry(name))
                z.write(data)
                z.closeEntry()
            }

            put("manifest.json", manifest().toByteArray())
            put("ui/_ui_defs.json", uiDefs.toByteArray())
            put("ui/custom_home.json", screen(items, bg).toByteArray())

            val sd = JSONObject()
            for (e in items) {
                e.png?.let { put("textures/ui/custom/el_${e.id}.png", it) }
                e.ogg?.let {
                    put("sounds/custom/el_${e.id}.ogg", it)
                    val sound = JSONObject()
                        .put("name", "sounds/custom/el_${e.id}")
                        .put("volume", 1.0)
                    sd.put("custom.el_${e.id}", JSONObject()
                        .put("category", "ui")
                        .put("sounds", JSONArray().put(sound)))
                }
            }
            val defs = JSONObject().put("format_version", "1.14.0").put("sound_definitions", sd)
            put("sounds/sound_definitions.json", defs.toString().toByteArray())
        }
    }

    private fun manifest(): String = """
{
  "format_version": 2,
  "header": {
    "name": "Home Editor",
    "description": "Custom home screen",
    "uuid": "${UUID.randomUUID()}",
    "version": [1, 0, 0]
  },
  "modules": [
    { "type": "resources", "uuid": "${UUID.randomUUID()}", "version": [1, 0, 0] }
  ]
}
""".trimIndent()

    private fun rgb(c: Int): JSONArray = JSONArray()
        .put(Color.red(c) / 255.0)
        .put(Color.green(c) / 255.0)
        .put(Color.blue(c) / 255.0)

    private fun screen(items: List<Element>, bg: Int): String {
        val controls = JSONArray()
        // фон экрана
        controls.put(JSONObject().put("bg", JSONObject()
            .put("type", "panel")
            .put("size", JSONArray().put(EditorView.VW.toInt()).put(EditorView.VH.toInt()))
            .put("color", rgb(bg))))

        for (e in items) {
            val body = JSONObject()
                .put("size", JSONArray().put(e.w.toInt()).put(e.h.toInt()))
                .put("offset", JSONArray().put(e.x.toInt()).put(e.y.toInt()))
                .put("anchor_from", "top_left")
                .put("anchor_to", "top_left")
            if (e.png != null) {
                body.put("type", "image").put("texture", "textures/ui/custom/el_${e.id}")
            } else {
                val label = JSONObject()
                    .put("type", "label")
                    .put("text", if (e.type == "image") "картинка" else e.text)
                    .put("color", JSONArray().put(1).put(1).put(1))
                    .put("size", JSONArray().put("100%").put("100%"))
                body.put("type", "panel")
                    .put("color", rgb(e.color))
                    .put("alpha", Color.alpha(e.color) / 255.0)
                    .put("controls", JSONArray().put(JSONObject().put("label_${e.id}", label)))
            }
            controls.put(JSONObject().put("el_${e.id}", body))
        }

        val root = JSONObject().put("namespace", "custom_home")
        root.put("custom_root", JSONObject()
            .put("type", "panel")
            .put("size", JSONArray().put(EditorView.VW.toInt()).put(EditorView.VH.toInt()))
            .put("controls", controls))
        return root.toString(2)
    }
}
