package com.example.homeeditor

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** ref — имя элемента в start_screen_content, defKey — ключ его описания в start_screen.json. */
class Item(val ref: String, val defKey: String)

/** Ресурс-пак: все файлы в памяти, главный экран — ui/start_screen.json. */
class Pack {
    private val files = LinkedHashMap<String, ByteArray>()
    private lateinit var screen: JSONObject
    private var counter = 1

    fun load(zip: ByteArray) {
        ZipInputStream(zip.inputStream()).use { z ->
            while (true) {
                val e: ZipEntry = z.nextEntry ?: break
                if (!e.isDirectory) files[e.name] = z.readBytes()
            }
        }
        val raw = files["ui/start_screen.json"]
            ?: throw IllegalStateException("В архиве нет ui/start_screen.json (это должен быть пак с главным экраном)")
        screen = JSONObject(String(raw, Charsets.UTF_8).removePrefix("\uFEFF"))
    }

    // ---------- чтение ----------

    fun texture(path: String): ByteArray? = files["$path.png"] ?: files["$path.jpg"] ?: files[path]

    fun defOf(defKey: String): JSONObject? = screen.optJSONObject(defKey)

    private fun controls(): JSONArray = screen.getJSONObject("start_screen_content").getJSONArray("controls")

    /** Элементы экрана в порядке отрисовки. */
    fun items(): List<Item> {
        val list = mutableListOf<Item>()
        val c = screen.optJSONObject("start_screen_content")?.optJSONArray("controls") ?: return list
        for (i in 0 until c.length()) {
            val key = c.getJSONObject(i).keys().asSequence().firstOrNull() ?: continue
            if (!key.startsWith("@start.")) continue
            val ref = key.removePrefix("@start.")
            val dk = defKeyOf(ref) ?: continue
            list.add(Item(ref, dk))
        }
        return list
    }

    private fun defKeyOf(ref: String): String? {
        if (screen.has(ref)) return ref
        val it = screen.keys()
        while (it.hasNext()) {
            val k = it.next()
            if (k.startsWith("$ref@")) return k
        }
        return null
    }

    /** Кнопки, у которых задан текст ($button_text), например «Играть». */
    fun buttonTexts(): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val it = screen.keys()
        while (it.hasNext()) {
            val k = it.next()
            val d = screen.optJSONObject(k) ?: continue
            if (k.contains("@") && d.has("\$button_text")) out.add(k to d.getString("\$button_text"))
        }
        return out
    }

    // ---------- изменения ----------

    private fun geo(d: JSONObject, r: R) {
        d.put("anchor_from", "top_left").put("anchor_to", "top_left")
        d.put("offset", JSONArray().put(r.x.toInt()).put(r.y.toInt()))
        d.put("size", JSONArray().put(r.w.toInt()).put(r.h.toInt()))
    }

    fun setGeometry(defKey: String, r: R) {
        geo(defOf(defKey) ?: return, r)
    }

    fun setColor(defKey: String, argb: Int) {
        val d = defOf(defKey) ?: return
        d.put("color", JSONArray()
            .put(Color.red(argb) / 255.0)
            .put(Color.green(argb) / 255.0)
            .put(Color.blue(argb) / 255.0))
    }

    fun setText(defKey: String, text: String) {
        val d = defOf(defKey) ?: return
        if (d.has("\$button_text")) d.put("\$button_text", text)
        else if (d.optString("type") == "label") d.put("text", text)
    }

    fun setTexture(defKey: String, png: ByteArray) {
        val path = defOf(defKey)?.optString("texture", "") ?: return
        if (path.isNotEmpty()) files["$path.png"] = png
    }

    private fun newRef(kind: String) = "custom_${kind}_${counter++}"

    private fun attach(defKey: String, def: JSONObject, ref: String) {
        screen.put(defKey, def)
        controls().put(JSONObject().put("@start.$ref", JSONObject()))
    }

    fun addButton(text: String, r: R): String {
        val ref = newRef("btn")
        val def = JSONObject().put("\$button_text", text)
        geo(def, r)
        attach("$ref@common_buttons.light_text_button", def, ref)
        return ref
    }

    fun addLabel(text: String, argb: Int, r: R): String {
        val ref = newRef("txt")
        val def = JSONObject().put("type", "label").put("text", text)
        geo(def, r)
        def.put("color", JSONArray()
            .put(Color.red(argb) / 255.0).put(Color.green(argb) / 255.0).put(Color.blue(argb) / 255.0))
        attach(ref, def, ref)
        return ref
    }

    fun addImage(png: ByteArray, r: R): String {
        val ref = newRef("img")
        val path = "textures/gui/custom/$ref"
        files["$path.png"] = png
        val def = JSONObject().put("type", "image").put("texture", path)
        geo(def, r)
        attach(ref, def, ref)
        return ref
    }

    fun addSound(ogg: ByteArray): String {
        val name = newRef("snd")
        files["sounds/custom/$name.ogg"] = ogg
        val defs = files["sounds/sound_definitions.json"]?.let { JSONObject(String(it, Charsets.UTF_8)) }
            ?: JSONObject().put("format_version", "1.14.0")
        if (!defs.has("sound_definitions")) defs.put("sound_definitions", JSONObject())
        defs.getJSONObject("sound_definitions").put(
            "custom.$name",
            JSONObject().put("category", "ui")
                .put("sounds", JSONArray().put(JSONObject().put("name", "sounds/custom/$name")))
        )
        files["sounds/sound_definitions.json"] = defs.toString(2).toByteArray(Charsets.UTF_8)
        return name
    }

    /** Убирает элемент с экрана. Свои элементы удаляются полностью, исходные только скрываются. */
    fun remove(ref: String) {
        val c = controls()
        for (i in c.length() - 1 downTo 0) {
            if (c.getJSONObject(i).keys().asSequence().firstOrNull() == "@start.$ref") c.remove(i)
        }
        if (ref.startsWith("custom_")) {
            defKeyOf(ref)?.let { screen.remove(it) }
            files.remove("textures/gui/custom/$ref.png")
        }
    }

    // ---------- сохранение ----------

    fun write(out: OutputStream) {
        files["ui/start_screen.json"] = screen.toString(2).toByteArray(Charsets.UTF_8)
        ZipOutputStream(out).use { z ->
            for ((name, data) in files) {
                z.putNextEntry(ZipEntry(name))
                z.write(data)
                z.closeEntry()
            }
        }
    }
}
