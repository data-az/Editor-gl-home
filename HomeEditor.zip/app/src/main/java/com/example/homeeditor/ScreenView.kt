package com.example.homeeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import org.json.JSONObject

/** Превью главного экрана. Рисует элементы из пака и позволяет двигать и менять размер. */
class ScreenView(context: Context) : View(context) {

    companion object {
        private const val HANDLE = 36f
        private const val BG = "textures/gui/background/1364910414_1"
    }

    var pack: Pack? = null
        set(v) {
            field = v
            bmps.clear()
            refresh()
        }

    var selected: String? = null
        private set
    var onSelect: ((String?) -> Unit)? = null

    private val rects = LinkedHashMap<String, R>()
    private val defKeys = HashMap<String, String>()
    private val bmps = HashMap<String, Bitmap>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private var scale = 1f
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f

    /** Перечитывает положения элементов из пака (после добавления или удаления). */
    fun refresh() {
        rects.clear()
        defKeys.clear()
        val p = pack ?: run { invalidate(); return }
        val screen = R(0f, 0f, Geo.SW, Geo.SH)
        for (item in p.items()) {
            val def = p.defOf(item.defKey) ?: continue
            rects[item.ref] = Geo.resolve(def, screen)
            defKeys[item.ref] = item.defKey
        }
        invalidate()
    }

    fun select(ref: String?) {
        selected = ref
        onSelect?.invoke(ref)
        invalidate()
    }

    fun defKeyFor(ref: String): String? = defKeys[ref]

    fun removeSelected() {
        val ref = selected ?: return
        pack?.remove(ref)
        select(null)
        refresh()
    }

    fun resizeSelected(f: Float) {
        val ref = selected ?: return
        val r = rects[ref] ?: return
        r.w = clampF(r.w * f, 12f, Geo.SW - r.x)
        r.h = clampF(r.h * f, 8f, Geo.SH - r.y)
        commit()
        invalidate()
    }

    private fun commit() {
        val ref = selected ?: return
        val r = rects[ref] ?: return
        val dk = defKeys[ref] ?: return
        pack?.setGeometry(dk, r)
    }

    private fun bitmap(path: String): Bitmap? {
        bmps[path]?.let { return it }
        val bytes = pack?.texture(path) ?: return null
        val b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        bmps[path] = b
        return b
    }

    private fun colorOf(def: JSONObject, fallback: Int): Int {
        val a = def.optJSONArray("color") ?: return fallback
        fun ch(i: Int) = (a.optDouble(i, 0.0) * 255).toInt().coerceIn(0, 255)
        return Color.rgb(ch(0), ch(1), ch(2))
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#101010"))
        val p = pack ?: return
        scale = width / Geo.SW
        c.save()
        c.scale(scale, scale)

        bitmap(BG)?.let { c.drawBitmap(it, null, RectF(0f, 0f, Geo.SW, Geo.SH), null) }

        for ((ref, r) in rects) {
            val def = p.defOf(defKeys[ref] ?: continue) ?: continue
            box.set(r.x, r.y, r.x + r.w, r.y + r.h)
            when (def.optString("type")) {
                "image" -> {
                    val b = bitmap(def.optString("texture", ""))
                    if (b != null) c.drawBitmap(b, null, box, null)
                    else drawBox(c, ref, Color.argb(120, 90, 90, 90), Color.WHITE)
                }
                "label" -> drawBox(c, def.optString("text", ref), Color.TRANSPARENT, colorOf(def, Color.WHITE))
                else -> {
                    val text = def.optString("\$button_text", ref)
                    drawBox(c, text, Color.argb(150, 60, 110, 200), Color.WHITE)
                }
            }
            if (ref == selected) drawSelection(c)
        }
        c.restore()
    }

    private fun drawBox(c: Canvas, text: String, fill: Int, textColor: Int) {
        paint.style = Paint.Style.FILL
        paint.color = fill
        c.drawRect(box, paint)
        paint.color = textColor
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = minOf(box.height() * 0.5f, 40f).coerceAtLeast(8f)
        c.drawText(text, box.centerX(), box.centerY() + paint.textSize / 3, paint)
    }

    private fun drawSelection(c: Canvas) {
        val ref = selected ?: return
        val r = rects[ref] ?: return
        box.set(r.x, r.y, r.x + r.w, r.y + r.h)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.YELLOW
        c.drawRect(box, paint)
        paint.style = Paint.Style.FILL
        box.set(r.x + r.w - HANDLE / 2, r.y + r.h - HANDLE / 2, r.x + r.w + HANDLE / 2, r.y + r.h + HANDLE / 2)
        c.drawRect(box, paint)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val vx = ev.x / scale
        val vy = ev.y / scale
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val s = selected?.let { rects[it] }
                val onHandle = s != null &&
                    vx in (s.x + s.w - HANDLE)..(s.x + s.w + HANDLE) &&
                    vy in (s.y + s.h - HANDLE)..(s.y + s.h + HANDLE)
                mode = if (onHandle) 2 else 0
                if (mode == 0) {
                    val hit = rects.entries.lastOrNull { e ->
                        val r = e.value
                        vx in r.x..(r.x + r.w) && vy in r.y..(r.y + r.h)
                    }?.key
                    select(hit)
                    mode = if (hit != null) 1 else 0
                }
                lastX = vx
                lastY = vy
            }
            MotionEvent.ACTION_MOVE -> {
                val ref = selected ?: return true
                val r = rects[ref] ?: return true
                val dx = vx - lastX
                val dy = vy - lastY
                if (mode == 1) {
                    r.x = clampF(r.x + dx, 0f, Geo.SW - r.w)
                    r.y = clampF(r.y + dy, 0f, Geo.SH - r.h)
                } else if (mode == 2) {
                    r.w = clampF(r.w + dx, 12f, Geo.SW - r.x)
                    r.h = clampF(r.h + dy, 8f, Geo.SH - r.y)
                }
                lastX = vx
                lastY = vy
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode != 0) commit()
                mode = 0
            }
        }
        return true
    }
}
