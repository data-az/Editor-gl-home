package com.example.homeeditor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var screen: ScreenView
    private lateinit var info: TextView
    private var pack: Pack? = null

    private val palette = linkedMapOf(
        "Белый" to "#FFFFFF", "Чёрный" to "#000000", "Жёлтый" to "#FDD835",
        "Красный" to "#E53935", "Зелёный" to "#43A047", "Синий" to "#3A7BD5",
        "Фиолетовый" to "#8E24AA", "Оранжевый" to "#FB8C00", "Серый" to "#616161"
    )

    private val openPack = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Не удалось прочитать файл")
            val p = Pack()
            p.load(bytes)
            pack = p
            screen.pack = p
            screen.select(null)
            info.text = "Пак открыт. Нажмите элемент на экране."
        } catch (e: Exception) {
            toast("Ошибка: ${e.message}")
        }
    }

    private val addImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val p = pack ?: return@registerForActivityResult
        val png = readPng(uri) ?: return@registerForActivityResult
        val ref = p.addImage(png, center(240f, 160f))
        screen.refresh()
        screen.select(ref)
    }

    private val replaceImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val p = pack ?: return@registerForActivityResult
        val ref = screen.selected ?: return@registerForActivityResult
        val dk = screen.defKeyFor(ref) ?: return@registerForActivityResult
        val png = readPng(uri) ?: return@registerForActivityResult
        p.setTexture(dk, png)
        screen.refresh()
        info.text = "Картинка заменена в паке"
    }

    private val addSound = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val p = pack ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        val isOgg = bytes != null && bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "OggS"
        if (bytes == null || !isOgg) {
            toast("Нужен файл .ogg (Bedrock не играет mp3 и wav)")
            return@registerForActivityResult
        }
        val name = p.addSound(bytes)
        info.text = "Звук добавлен в пак: $name. Привязка к кнопке пока не сделана."
    }

    private val saveZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val p = pack ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        contentResolver.openOutputStream(uri)?.use { p.write(it) }
        toast("Пак сохранён")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        screen = ScreenView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            onSelect = { ref -> info.text = describe(ref) }
        }
        info = TextView(this).apply { textSize = 14f; setPadding(16, 8, 16, 8) }
        info.text = "Нажмите «Открыть пак» и выберите свой fon.zip"

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        btn("Открыть пак") { openPack.launch(arrayOf("*/*")) }
        btn("Сохранить") { if (pack == null) toast("Сначала откройте пак") else saveZip.launch("edited.mcpack") }
        btn("+Кнопка") {
            withPack { p ->
                askText("Текст кнопки") { t -> screen.select(p.addButton(t, center(200f, 40f))); screen.refresh() }
            }
        }
        btn("+Текст") {
            withPack { p ->
                askText("Текст") { t -> screen.select(p.addLabel(t, Color.WHITE, center(240f, 40f))); screen.refresh() }
            }
        }
        btn("+Картинка") { if (pack != null) addImage.launch("image/*") else toast("Сначала откройте пак") }
        btn("Заменить картинку") { if (requireSel()) replaceImage.launch("image/*") }
        btn("+Звук") { if (pack != null) addSound.launch("*/*") else toast("Сначала откройте пак") }
        btn("Текст▸") {
            withSel { ref, dk ->
                val p = pack ?: return@withSel
                askText("Текст", p.defOf(dk)?.optString("text") ?: "") { t -> p.setText(dk, t); screen.refresh() }
            }
        }
        btn("Текст кнопок") { editButtonTexts() }
        btn("Цвет") {
            withSel { _, dk -> pickColor { c -> pack?.setColor(dk, c); screen.refresh() } }
        }
        btn("Больше") { screen.resizeSelected(1.1f) }
        btn("Меньше") { screen.resizeSelected(0.9f) }
        btn("Удалить") { screen.removeSelected() }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(HorizontalScrollView(this@MainActivity).apply { addView(bar) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(info)
            addView(screen)
        })
    }

    private fun describe(ref: String?): String {
        val p = pack ?: return ""
        if (ref == null) return "Нажмите элемент на экране"
        val dk = screen.defKeyFor(ref) ?: return ref
        val d = p.defOf(dk)
        val type = d?.optString("type") ?: "?"
        return "$ref ($type)  перетаскивайте или тяните угол"
    }

    private fun center(w: Float, h: Float) = R((Geo.SW - w) / 2, (Geo.SH - h) / 2, w, h)

    private fun readPng(uri: android.net.Uri?): ByteArray? {
        if (uri == null) return null
        val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val bmp: Bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: run {
            toast("Файл не является картинкой")
            return null
        }
        return ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    }

    private fun requireSel(): Boolean {
        if (screen.selected == null) toast("Сначала выберите элемент")
        return screen.selected != null
    }

    private fun withPack(block: (Pack) -> Unit) {
        val p = pack
        if (p == null) toast("Сначала откройте пак") else block(p)
    }

    private fun withSel(block: (String, String) -> Unit) {
        if (!requireSel()) return
        val ref = screen.selected ?: return
        val dk = screen.defKeyFor(ref) ?: return
        block(ref, dk)
    }

    private fun editButtonTexts() {
        val p = pack ?: return toast("Сначала откройте пак")
        val list = p.buttonTexts()
        if (list.isEmpty()) return toast("В паке нет кнопок с текстом")
        AlertDialog.Builder(this)
            .setTitle("Какую кнопку переименовать?")
            .setItems(list.map { "${it.second}" }.toTypedArray()) { _, i ->
                val (dk, cur) = list[i]
                askText("Текст кнопки", cur) { t -> p.setText(dk, t); screen.refresh() }
            }
            .show()
    }

    private fun askText(title: String, prefill: String = "", done: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(prefill)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> done(input.text.toString()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pickColor(apply: (Int) -> Unit) {
        val names = palette.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Цвет")
            .setItems(names) { _, i -> apply(Color.parseColor(palette.values.elementAt(i))) }
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
