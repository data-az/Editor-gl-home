package com.example.homeeditor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {
    private val model = Model()
    private lateinit var view: EditorView
    private lateinit var info: TextView

    private val palette = linkedMapOf(
        "Синий" to "#3A7BD5", "Белый" to "#FFFFFF", "Чёрный" to "#000000",
        "Жёлтый" to "#FDD835", "Красный" to "#E53935", "Зелёный" to "#43A047",
        "Фиолетовый" to "#8E24AA", "Оранжевый" to "#FB8C00", "Серый" to "#616161"
    )

    private val pickNewImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val (png, bmp) = decode(uri) ?: return@registerForActivityResult
        val e = model.newEl(Kind.IMAGE, "", model.centerX(240f), model.centerY(160f), 240f, 160f)
        e.png = png
        e.bitmap = bmp
        view.select(e)
    }

    private val replaceImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val e = view.selected ?: return@registerForActivityResult
        val (png, bmp) = decode(uri) ?: return@registerForActivityResult
        e.png = png
        e.bitmap = bmp
        view.invalidate()
    }

    private val pickBackground = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val (png, bmp) = decode(uri) ?: return@registerForActivityResult
        model.bgPng = png
        model.bgBitmap = bmp
        view.invalidate()
        info.text = "Фон установлен (статичный)"
    }

    private val saveZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { PackWriter.write(it, model.els, model.bgPng) }
            toast("Пак сохранён")
        } catch (e: Exception) {
            toast("Не удалось сохранить: ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        info = TextView(this).apply { textSize = 14f; setPadding(16, 8, 16, 8) }
        info.text = "Нажмите элемент, чтобы выбрать. Перетаскивайте, тяните жёлтый угол для размера."

        view = EditorView(this, model).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            onSelect = { e -> info.text = describe(e) }
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        btn("+Кнопка") {
            askText("Текст кнопки") { t ->
                view.select(model.newEl(Kind.BUTTON, t, model.centerX(200f), model.centerY(40f), 200f, 40f))
            }
        }
        btn("+Текст") {
            askText("Текст") { t ->
                val e = model.newEl(Kind.LABEL, t, model.centerX(240f), model.centerY(40f), 240f, 40f)
                e.color = Color.WHITE
                view.select(e)
            }
        }
        btn("+Картинка") { pickNewImage.launch("image/*") }
        btn("Заменить картинку") {
            if (requireSel(Kind.IMAGE)) replaceImage.launch("image/*")
        }
        btn("Фон") { pickBackground.launch("image/*") }
        btn("Текст▸") {
            val e = view.selected ?: return@btn toast("Выберите кнопку или текст")
            if (e.kind == Kind.IMAGE) return@btn toast("У картинки нет текста")
            askText("Текст", e.text) { t -> e.text = t; view.invalidate() }
        }
        btn("Цвет") {
            val e = view.selected ?: return@btn toast("Выберите элемент")
            if (e.kind == Kind.IMAGE) return@btn toast("У картинки нет цвета")
            pickColor { c -> e.color = c; view.invalidate() }
        }
        btn("Больше") { view.resizeSelected(1.1f) }
        btn("Меньше") { view.resizeSelected(0.9f) }
        btn("Удалить") { view.deleteSelected() }
        btn("Сохранить") { saveZip.launch("my_menu.mcpack") }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(HorizontalScrollView(this@MainActivity).apply { addView(bar) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(info)
            addView(view)
        })
    }

    private fun describe(e: El?): String {
        if (e == null) return "Нажмите элемент на экране"
        val name = when (e.kind) {
            Kind.BUTTON -> "кнопка"
            Kind.LABEL -> "текст"
            Kind.IMAGE -> "картинка"
        }
        return "$name: ${e.text.ifEmpty { "без текста" }}  ${e.w.toInt()}×${e.h.toInt()}"
    }

    /** Возвращает PNG-байты и готовый Bitmap. */
    private fun decode(uri: Uri?): Pair<ByteArray, Bitmap>? {
        if (uri == null) return null
        val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size)
        if (bmp == null) {
            toast("Файл не является картинкой")
            return null
        }
        val png = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        return png to bmp
    }

    private fun requireSel(kind: Kind? = null): Boolean {
        val e = view.selected
        if (e == null) {
            toast("Сначала выберите элемент")
            return false
        }
        if (kind != null && e.kind != kind) {
            toast("Этот элемент не подходит")
            return false
        }
        return true
    }

    private fun askText(title: String, prefill: String = "", done: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(prefill)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> done(input.text.toString()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pickColor(apply: (Int) -> Unit) {
        val names = palette.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Цвет")
            .setItems(names) { _, i -> apply(Color.parseColor(palette.values.elementAt(i))) }
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
