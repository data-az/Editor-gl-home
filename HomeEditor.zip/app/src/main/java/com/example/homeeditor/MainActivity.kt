package com.example.homeeditor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditorView
    private lateinit var info: TextView

    private val palette = linkedMapOf(
        "Синий" to "#3A7BD5", "Красный" to "#E53935", "Зелёный" to "#43A047",
        "Жёлтый" to "#FDD835", "Фиолетовый" to "#8E24AA", "Оранжевый" to "#FB8C00",
        "Чёрный" to "#000000", "Белый" to "#FFFFFF", "Серый" to "#616161"
    )

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val el = editor.selected ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        val bmp = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        if (bmp == null) {
            toast("Не удалось открыть картинку")
            return@registerForActivityResult
        }
        // храним PNG: так текстура всегда подходит для пака
        val png = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        el.png = png
        el.bitmap = bmp
        editor.invalidate()
    }

    private val pickSound = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val el = editor.selected ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        val isOgg = bytes != null && bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "OggS"
        if (!isOgg) {
            toast("Нужен файл .ogg (Bedrock не играет mp3/wav)")
            return@registerForActivityResult
        }
        el.ogg = bytes
        info.text = "Звук добавлен: ${el.text}"
        editor.invalidate()
    }

    private val saveZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri == null) return@registerForActivityResult
        val defs = assets.open("ui_defs.json").bufferedReader().use { it.readText() }
        contentResolver.openOutputStream(uri)?.use { os ->
            PackExporter.export(os, editor.items, editor.bgColor, defs)
        }
        toast("Пак сохранён")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        editor = EditorView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        info = TextView(this).apply { textSize = 14f; setPadding(16, 8, 16, 8) }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        btn("+Кнопка") { askText("Текст кнопки") { t -> editor.add("button").apply { text = t } } }
        btn("+Текст") { askText("Текст") { t -> editor.add("text").apply { text = t; color = Color.TRANSPARENT } } }
        btn("+Картинка") { editor.add("image"); pickImage.launch("image/*") }
        btn("Фото") { if (requireSel()) pickImage.launch("image/*") }
        btn("Звук") { if (requireSel()) pickSound.launch("*/*") }
        btn("Текст▸") {
            editor.selected?.let { s -> askText("Текст", s.text) { t -> s.text = t; editor.invalidate() } }
        }
        btn("Цвет") {
            if (requireSel()) pickColor { c -> editor.selected?.color = c; editor.invalidate() }
        }
        btn("Фон") { pickColor { c -> editor.bgColor = c; editor.invalidate() } }
        btn("Больше") { editor.resizeSelected(1.1f) }
        btn("Меньше") { editor.resizeSelected(0.9f) }
        btn("Удалить") { editor.removeSelected() }
        btn("Экспорт") { saveZip.launch("home_editor.mcpack") }

        val scroll = HorizontalScrollView(this).apply { addView(bar) }

        editor.onSelect = { e ->
            info.text = e?.let { "${it.type}: ${it.text}  ${it.w.toInt()}×${it.h.toInt()}" } ?: "Нажмите элемент"
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(info)
            addView(editor)
        })
    }

    private fun requireSel(): Boolean {
        if (editor.selected == null) toast("Сначала выберите элемент")
        return editor.selected != null
    }

    private fun askText(title: String, prefill: String = "", done: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(prefill)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> done(input.text.toString()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pickColor(apply: (Int) -> Unit) {
        val names = palette.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Цвет")
            .setItems(names) { _, i -> apply(Color.parseColor(palette.values.elementAt(i))) }
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
