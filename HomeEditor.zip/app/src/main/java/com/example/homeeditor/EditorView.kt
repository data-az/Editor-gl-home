package com.example.homeeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View

/** Главный экран, который можно двигать и менять. */
class EditorView(context: Context, private val model: Model) : View(context) {

    companion object {
        private const val HANDLE = 36f
    }

    var selected: El? = null
        private set
    var onSelect: ((El?) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private var scale = 1f
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f

    fun select(e: El?) {
        selected = e
        onSelect?.invoke(e)
        invalidate()
    }

    fun deleteSelected() {
        selected?.let { model.els.remove(it) }
        select(null)
    }

    fun resizeSelected(f: Float) {
        val e = selected ?: return
        e.w = clampF(e.w * f, 12f, Model.SW - e.x)
        e.h = clampF(e.h * f, 8f, Model.SH - e.y)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        scale = width / Model.SW
        c.drawColor(Color.BLACK)
        c.save()
        c.scale(scale, scale)

        val bg = model.bgBitmap
        if (bg != null) {
            box.set(0f, 0f, Model.SW, Model.SH)
            c.drawBitmap(bg, null, box, null)
        } else {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, 0f, 0f, Model.SH,
                Color.parseColor("#2B3F6B"), Color.parseColor("#0B1224"), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, Model.SW, Model.SH, p)
            p.shader = null
        }

        for (e in model.els) draw(c, e)
        selected?.let { drawSelection(c, it) }
        c.restore()
    }

    private fun draw(c: Canvas, e: El) {
        box.set(e.x, e.y, e.x + e.w, e.y + e.h)
        when (e.kind) {
            Kind.BUTTON -> {
                p.style = Paint.Style.FILL
                p.color = e.color
                c.drawRoundRect(box, 8f, 8f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                p.color = Color.WHITE
                c.drawRoundRect(box, 8f, 8f, p)
                drawText(c, e.text, Color.WHITE)
            }
            Kind.LABEL -> drawText(c, e.text, e.color)
            Kind.IMAGE -> {
                val b = e.bitmap
                if (b != null) {
                    c.drawBitmap(b, null, box, null)
                } else {
                    p.style = Paint.Style.FILL
                    p.color = Color.argb(120, 90, 90, 90)
                    c.drawRect(box, p)
                    drawText(c, "картинка", Color.WHITE)
                }
            }
        }
    }

    private fun drawText(c: Canvas, s: String, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        p.textAlign = Paint.Align.CENTER
        p.textSize = (box.height() * 0.5f).coerceIn(8f, 60f)
        c.drawText(s, box.centerX(), box.centerY() + p.textSize / 3, p)
    }

    private fun drawSelection(c: Canvas, e: El) {
        box.set(e.x, e.y, e.x + e.w, e.y + e.h)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.YELLOW
        c.drawRect(box, p)
        p.style = Paint.Style.FILL
        box.set(e.x + e.w - HANDLE / 2, e.y + e.h - HANDLE / 2, e.x + e.w + HANDLE / 2, e.y + e.h + HANDLE / 2)
        c.drawRect(box, p)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val vx = ev.x / scale
        val vy = ev.y / scale
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val s = selected
                val onHandle = s != null &&
                    vx in (s.x + s.w - HANDLE)..(s.x + s.w + HANDLE) &&
                    vy in (s.y + s.h - HANDLE)..(s.y + s.h + HANDLE)
                mode = if (onHandle) 2 else 0
                if (mode == 0) {
                    val hit = model.els.lastOrNull { vx in it.x..(it.x + it.w) && vy in it.y..(it.y + it.h) }
                    select(hit)
                    mode = if (hit != null) 1 else 0
                }
                lastX = vx
                lastY = vy
            }
            MotionEvent.ACTION_MOVE -> {
                val e = selected ?: return true
                val dx = vx - lastX
                val dy = vy - lastY
                if (mode == 1) {
                    e.x = clampF(e.x + dx, 0f, Model.SW - e.w)
                    e.y = clampF(e.y + dy, 0f, Model.SH - e.h)
                } else if (mode == 2) {
                    e.w = clampF(e.w + dx, 12f, Model.SW - e.x)
                    e.h = clampF(e.h + dy, 8f, Model.SH - e.y)
                }
                lastX = vx
                lastY = vy
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}

fun clampF(v: Float, lo: Float, hi: Float): Float = maxOf(lo, minOf(v, hi))
