package com.example.homeeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

class Element(val id: Int, var type: String) {
    var text = "Кнопка"
    var color = Color.parseColor("#3A7BD5")
    var x = 100f
    var y = 100f
    var w = 240f
    var h = 80f
    var png: ByteArray? = null
    var ogg: ByteArray? = null
    var bitmap: Bitmap? = null
}

fun clampF(v: Float, lo: Float, hi: Float): Float = maxOf(lo, minOf(v, hi))

class EditorView(context: Context) : View(context) {
    companion object {
        const val VW = 1280f
        const val VH = 720f
        private const val HANDLE = 40f
    }

    val items = mutableListOf<Element>()
    var selected: Element? = null
        private set
    var bgColor = Color.parseColor("#1B1B1B")
    var onSelect: ((Element?) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var scale = 1f
    private var nextId = 1
    private var dragMode = 0
    private var lastX = 0f
    private var lastY = 0f

    fun add(type: String): Element {
        val e = Element(nextId++, type)
        items.add(e)
        select(e)
        return e
    }

    fun select(e: Element?) {
        selected = e
        onSelect?.invoke(e)
        invalidate()
    }

    fun removeSelected() {
        selected?.let { items.remove(it) }
        select(null)
    }

    fun resizeSelected(f: Float) {
        val s = selected ?: return
        s.w = clampF(s.w * f, 20f, VW - s.x)
        s.h = clampF(s.h * f, 12f, VH - s.y)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        scale = width / VW
        c.drawColor(bgColor)
        c.save()
        c.scale(scale, scale)
        for (e in items) {
            rect.set(e.x, e.y, e.x + e.w, e.y + e.h)
            val bmp = e.bitmap
            if (bmp != null) {
                c.drawBitmap(bmp, null, rect, null)
            } else {
                paint.style = Paint.Style.FILL
                paint.color = e.color
                c.drawRect(rect, paint)
                paint.color = Color.WHITE
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = minOf(e.h * 0.5f, 60f)
                val label = if (e.type == "image") "картинка" else e.text
                c.drawText(label, rect.centerX(), rect.centerY() + paint.textSize / 3, paint)
            }
            if (e.ogg != null) {
                paint.color = Color.YELLOW
                paint.textAlign = Paint.Align.LEFT
                paint.textSize = 28f
                c.drawText("♪", rect.left + 8, rect.top + 30, paint)
            }
        }
        selected?.let { s ->
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            paint.color = Color.YELLOW
            rect.set(s.x, s.y, s.x + s.w, s.y + s.h)
            c.drawRect(rect, paint)
            paint.style = Paint.Style.FILL
            rect.set(s.x + s.w - HANDLE / 2, s.y + s.h - HANDLE / 2, s.x + s.w + HANDLE / 2, s.y + s.h + HANDLE / 2)
            c.drawRect(rect, paint)
        }
        c.restore()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val vx = ev.x / scale
        val vy = ev.y / scale
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val s = selected
                val onHandle = s != null &&
                    vx in (s.x + s.w - HANDLE)..(s.x + s.w + HANDLE) &&
                    vy in (s.y + s.h - HANDLE)..(s.y + s.h + HANDLE)
                dragMode = if (onHandle) 2 else 0
                if (dragMode == 0) {
                    val hit = items.lastOrNull { vx in it.x..(it.x + it.w) && vy in it.y..(it.y + it.h) }
                    select(hit)
                    dragMode = if (hit != null) 1 else 0
                }
                lastX = vx
                lastY = vy
            }
            MotionEvent.ACTION_MOVE -> {
                val s = selected ?: return true
                val dx = vx - lastX
                val dy = vy - lastY
                if (dragMode == 1) {
                    s.x = clampF(s.x + dx, 0f, VW - s.w)
                    s.y = clampF(s.y + dy, 0f, VH - s.h)
                } else if (dragMode == 2) {
                    s.w = clampF(s.w + dx, 20f, VW - s.x)
                    s.h = clampF(s.h + dy, 12f, VH - s.y)
                }
                lastX = vx
                lastY = vy
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragMode = 0
        }
        return true
    }
}
